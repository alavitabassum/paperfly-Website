<!--{

"title": "Download"

}-->
If you're using [Composer](http://getcomposer.org) you can use Crush in your project with the following line in your terminal:

```shell
composer require css-crush/css-crush:dev-master
```

If you're not using Composer yet just download the library  ([zip](http://github.com/peteboere/css-crush/zipball/master) or [tar](http://github.com/peteboere/css-crush/tarball/master)) into a convenient location and require the bootstrap file:

```php
<?php require_once 'path/to/CssCrush.php'; ?>
```

