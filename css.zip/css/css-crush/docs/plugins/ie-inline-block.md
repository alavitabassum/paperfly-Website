
Polyfill for display:inline-block in IE < 8

```css
display: inline-block;
```

```css
display: inline-block;
*display: inline;
*zoom: 1;
```