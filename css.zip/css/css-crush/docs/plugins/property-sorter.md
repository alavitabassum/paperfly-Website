
Property sorting.

Examples use the predefined property sorting table. To define a custom sorting order pass an array to `csscrush_set_property_sort_order()`


```css
color: red;
background: #000;
opacity: .5;
display: block;
position: absolute;
```

```css
position: absolute;
display: block;
opacity: .5;
color: red;
background: #000;
```
