
Composite :hover/:focus/:active pseudo classes.

```css
a:hocus { color: red; }
a:pocus { color: red; }
```

```css
a:hover, a:focus { color: red; }
a:hover, a:focus, a:active { color: red; }
```
