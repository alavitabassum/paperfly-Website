<!-------------------------------------- Bottom Navigation Bar -->
<!--<div id="goTop" onclick="smoothScroll('topOfPage');">-->
<!--    <a href="#topOfPage">-->
<!--        <img class="goTopImg" src="./img/gotop.png" alt="go to top of page ^">-->
<!--    </a>-->
<!--</div>-->

<nav class="bottomNavbar" role="navigation">
    <div class="bottomNavDiv">
        <ul class="navlist bottomNav">
<!--            <li><a href="support.php">Support</a></li>-->
            <!--<li><a href="./news.html">News</a></li>-->
<!--            <li><a href="./career.php">Career</a></li>-->
            <li><a href="./aboutus.php">About Us</a></li>
            <li><a href="./contact.php">Contact</a></li>
        </ul>
    </div>
</nav>

<div class="PFfooter">Copyright © <?php echo date("Y")?> &nbsp;<img src="./img/PFfavicon16.png">&nbsp; PaperFly Private Ltd. All rights reserved.</div>

<script>
    var scroll = new SmoothScroll('a[href*="#"]');
</script>

</body>

</html>