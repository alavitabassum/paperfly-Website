<?php include 'modHeader.php';?>

    <!-------------------------------------- Page Body -->

    <div class="pageCoverPanel shortHeight">
        <img class="pageCoverImg" src="./img/CoveragePCP.png" alt="Page Cover">
        <div class="pageCoverHeading">Coverage <span class="thinText">that</span> WORKS</div>
<!--        <div class="pageCoverIconPanel">-->
<!--            <img class="pageCoverIcon" src="./img/iconDSD.png" onclick="smoothScroll('svc1');">-->
<!--            <img class="pageCoverIcon" src="./img/iconCOD.png" onclick="smoothScroll('svc2');">-->
<!--            <img class="pageCoverIcon" src="./img/iconASA.png" onclick="smoothScroll('svc3');">-->
<!--            <img class="pageCoverIcon" src="./img/iconRet.png" onclick="smoothScroll('svc4');">-->
<!--            <img class="pageCoverIcon" src="./img/iconStD.png" onclick="smoothScroll('svc5');">-->
<!--            <img class="pageCoverIcon" src="./img/iconExD.png" onclick="smoothScroll('svc6');">-->
<!--            <img class="pageCoverIcon" src="./img/iconSmP.png" onclick="smoothScroll('svc7');">-->
<!--            <img class="pageCoverIcon" src="./img/iconWhs.png" onclick="smoothScroll('svc8');">-->
<!--            <img class="pageCoverIcon" src="./img/icon363.png" onclick="smoothScroll('svc9');">-->
<!--            <img class="pageCoverIcon" src="./img/iconDRM.png" onclick="smoothScroll('svc10');">-->
<!--        </div>-->
    </div>

    <div class="coverageMap" id="svc1">
        <div class="coverageMapText">Paperfly service coverage as of now:</div>
        <img class="coverageMapImage" src="./img/CvrgMap.png">
    </div>

<?php include 'modFooter.php';?>