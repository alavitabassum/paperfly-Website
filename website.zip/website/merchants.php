<?php include 'modHeader.php';?>

<!-------------------------------------- Page Body -->

<!-------------------------------------- Bubble Menu -->
<!--<div class="bubbleMenuContainer">-->
<!--    <div class="bubbleMenuIconContainer">-->
<!--        <div class="halfSpacer"></div>-->
<!--        <div class="dummy"></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#aaaaaa,#909090);"><a href="coverage.php#cvg1"><img class="bubbleMenuImage" src="./img/doorstep_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>Door Step Delivery</h2><p>We have a well-trained delivery team, who know ins and outs of their assigned geography. And being in the sector for more than a year have given this team confidene of reaching the Customer in minimum hassle.</p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#24B7FC,#188BF3);"><a href="coverage.php#cvg2"><img class="bubbleMenuImage" src="./img/cod_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>CoD Collection</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#FF2222,crimson);"><a href="coverage.php#cvg3"><img class="bubbleMenuImage" src="./img/any_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>Any Size Anywhere</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(red,darkorange);"><a href="coverage.php#cvg4"><img class="bubbleMenuImage" src="./img/return_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>Return Management</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(#7CFF67,#0AD51A);"><a href="coverage.php#cvg2"><img class="bubbleMenuImage" src="./img/cod_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>End to End Digital</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(pink,orchid);"><a href="coverage.php#cvg3"><img class="bubbleMenuImage" src="./img/any_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>14 Steps Delivery Tracking</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#24B7FC,#188BF3);"><a href="coverage.php#cvg4"><img class="bubbleMenuImage" src="./img/return_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>API Integration</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(#7CFF67,#0AD51A);"><a href="coverage.php#cvg1"><img class="bubbleMenuImage" src="./img/doorstep_pcp_icon_white.png"></a><div class="bubbleMenuDescription"><h2>Electronic Invoicing</h2><p></p></div></div>-->
<!--        <div class="halfSpacer"></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(red,darkorange);"><a href="products.php#cvg1"><img class="bubbleMenuImage" src="./img/iconHapiness.png"></a><div class="bubbleMenuDescription"><h2>Delivering Happiness</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(pink,orchid);"><a href="coverage.php#cvg2"><img class="bubbleMenuImage" src="./img/iconSmartPP.png"></a><div class="bubbleMenuDescription"><h2>SmartPICK & SmartPACK</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(red,darkorange);"><a href="coverage.php#cvg3"><img class="bubbleMenuImage" src="./img/iconExpress.png"></a><div class="bubbleMenuDescription"><h2>Express Delivery</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#24B7FC,#188BF3);"><a href="coverage.php#cvg4"><img class="bubbleMenuImage" src="./img/iconWarehouse.png"></a><div class="bubbleMenuDescription"><h2>Warehousing Solutions</h2><p></p></div></div>-->
<!--        <div class="dummy"></div>-->
<!--        <div class="bubbleMenuItem" style="background: radial-gradient(#7CFF67,#0AD51A);"><a href="coverage.php#cvg1"><img class="bubbleMenuImage" src="./img/icon363Days.png"></a><div class="bubbleMenuDescription"><h2>363 Days Service</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#24B7FC,#188BF3);"><a href="coverage.php#cvg2"><img class="bubbleMenuImage" src="./img/iconDedicatedRM.png"></a><div class="bubbleMenuDescription"><h2>Dedicated Relationship Managers</h2><p></p></div></div>-->
<!--        <div class="bubbleMenuItem" style="background: linear-gradient(#FF2222,crimson);"><a href="coverage.php#cvg2"><img class="bubbleMenuImage" src="./img/iconCustomize.png"></a><div class="bubbleMenuDescription"><h2>Custom Tailored Services</h2><p></p></div></div>-->
<!--    </div>-->
<!--</div>-->

<!-------------------------------------- Reg Form -->

<div class="pageCoverPanel shortHeight">
    <img class="pageCoverImg imgBlurEfx" src="./img/MerchantPCP.jpg" alt="Page Cover">
    <div class="pageCoverHeading">Register <span class="thinText">as a</span> MERCHANT</div>
</div>
<div class="stdFormContainer">
    <?php include 'frm_merchant_reg.php'?>
</div>

<?php include 'modFooter.php';?>